package com.rocket.crm.entity;

public class Customer {

}
