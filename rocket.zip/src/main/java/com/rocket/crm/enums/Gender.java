package com.rocket.crm.enums;

public enum Gender {
	MALE, FEMALE, OTHER
}
