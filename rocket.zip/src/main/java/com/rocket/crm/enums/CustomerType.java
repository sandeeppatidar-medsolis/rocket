package com.rocket.crm.enums;

public enum CustomerType {
	LEAD, CUSTOMER

}
