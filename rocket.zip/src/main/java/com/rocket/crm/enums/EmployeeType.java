package com.rocket.crm.enums;

public enum EmployeeType {
	EMPLOYEE, AGENT

}
